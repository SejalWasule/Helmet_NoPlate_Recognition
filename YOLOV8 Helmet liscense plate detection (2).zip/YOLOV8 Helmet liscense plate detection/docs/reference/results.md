### Results API Reference

:::ultralytics.yolo.engine.results.Results

### Boxes API Reference

:::ultralytics.yolo.engine.results.Boxes

### Masks API Reference

:::ultralytics.yolo.engine.results.Masks
