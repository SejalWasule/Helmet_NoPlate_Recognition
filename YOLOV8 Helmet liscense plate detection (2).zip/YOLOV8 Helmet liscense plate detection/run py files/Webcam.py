import cv2
from ultralytics import YOLO

# Load the YOLOv8 model
model = YOLO('best106.pt')  # Replace with the path to your YOLOv8 model

# Open the webcam
cap = cv2.VideoCapture(0)  # 0 for the default camera

while cap.isOpened():
    # Read a frame from the webcam
    success, frame = cap.read()

    if success:
        # Run YOLOv8 inference on the frame
        results = model(frame)

        # Display the frame with detections (you can customize this part)
        cv2.imshow("YOLOv8 Inference", frame)

        # Break the loop if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    else:
        # Break the loop if there's an issue with the webcam or it's closed
        break

# Release the webcam and close the display window
cap.release()
cv2.destroyAllWindows()