import os
import cv2
from PIL import Image
from ultralytics import YOLO

# Load the YOLOv8 model
model = YOLO('best106.pt')

# Path to the input image folder
input_folder = "Input images"

# Path to the output (annotated images) folder
output_folder = "predout"

# Create the output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# List all files in the input folder
image_files = os.listdir(input_folder)

# Process each image in the folder
for image_file in image_files:
    # Check if the file is an image (you may want to add more file format checks)
    if image_file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
        # Read the image using OpenCV
        image_path = os.path.join(input_folder, image_file)
        frame = cv2.imread(image_path)

        # Convert OpenCV image (BGR format) to RGB (PIL format)
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame = Image.fromarray(frame)

        # Perform YOLOv8 inference on the image
        results = model(frame)

        # Visualize the results on the image
        annotated_image = results.show()

        # Save the annotated image to the output folder with a unique filename
        output_path = os.path.join(output_folder, f"annotated_{image_file}")
        annotated_image.save(output_path)

print("All images processed and saved in the 'predOut' folder.")
